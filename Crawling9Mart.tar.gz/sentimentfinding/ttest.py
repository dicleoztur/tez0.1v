'''
Created on Feb 3, 2013

@author: dicle
'''

import os

magnitude_path = "/home/dicle/Dropbox/Tez/system/data/magnitude/"
extent = ["small", "big"]

z = globals()["extent"]

#t = globals()["e"]

print z


'''
keywordindices = ["polarity","country","magnitude"]
rootpath = "/home/dicle/Dropbox/Tez/system/keywordbase/"


files = os.listdir(rootpath+"polarity"+os.sep+"new")

for file in files:
    print file.split(".")[0]," ",type(file)

'''

keywordindices = ["polarity","country","magnitude"]
choice = "countr"


